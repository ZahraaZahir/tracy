import {Response} from 'express';
import {AuthenticatedRequest} from '../types/auth.types.js';
import {EntityService} from '../services/entity.service.js';
import {WorldService} from '../services/world.service.js';
import {PuzzleService} from '../services/puzzle.service.js';
import {LeaderboardService} from '../services/leaderboard.service.js';
import {ValueMatchStrategy} from '../services/strategies/value-match.strategy.js';
import {EntityRepository} from '../repositories/entity.repository.js';
import {WorldRepository} from '../repositories/world.repository.js';
import {
  entityParamSchema,
  solveEntitySchema,
} from '../validators/entity.validator.js';

let entityService: EntityService;
let worldService: WorldService;
let puzzleService: PuzzleService;
const lbService = new LeaderboardService();

const initServices = () => {
  if (!worldService) {
    const worldRepo = new WorldRepository();
    const entityRepo = new EntityRepository();
    entityService = new EntityService(entityRepo);
    worldService = new WorldService(worldRepo, entityRepo);
    puzzleService = new PuzzleService(
      entityRepo,
      worldRepo,
      new ValueMatchStrategy(),
    );
  }
};

export const getEntity = async (req: AuthenticatedRequest, res: Response) => {
  initServices();
  const {id} = entityParamSchema.parse(req.params);
  const userId = req.user!.sub;

  const playerState = await worldService.load(userId);
  const isFixed = playerState.fixedGlitches.includes(id);

  const entityData = await entityService.getEntityState(id, isFixed);

  res.status(200).json({
    message: 'Entity state retrieved',
    data: {
      ...entityData,
      inventory: playerState.inventory || [],
    },
  });
};

export const solveEntity = async (req: AuthenticatedRequest, res: Response) => {
  initServices();
  const {id} = entityParamSchema.parse(req.params);
  const {answers} = solveEntitySchema.parse(req.body);

  const {sub, username} = req.user!;

  const result = await puzzleService.solve(sub, id, answers);

  if (result.success && typeof result.fixedCount === 'number') {
    await lbService.updateRank(sub, result.fixedCount);
  }

  res.status(result.success ? 200 : 400).json({
    message: result.message || (result.success ? 'Fixed!' : 'Failed'),
    data: result,
  });
};